# Executive Painting LLC — Responsive Landing Page

This is a standalone HTML/CSS/JS recreation based on the supplied screenshot.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive styling
- `script.js` — mobile navigation + demo form behavior

## Run locally
Open `index.html` in a browser.

## Put it on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Set the source to the `main` branch and `/root`.
5. Save and open the generated GitHub Pages URL.

## Before using it as a real client site
- Replace the placeholder phone number and email.
- Replace the remote Unsplash images with the client's actual project photos.
- Connect the quote form to the client's CRM/form endpoint.
- Replace any placeholder service-area copy with the client's exact service areas.
